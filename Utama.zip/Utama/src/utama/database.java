/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utama;

/**
 *
 * @author Adi Arput
 */
public class database {
    public void namaLengkap(){
        System.out.println("Nama Lengkap : Adi Putra");
    }
    public void jenisKelamin(){
        System.out.println("jenis Kelamin : Laki-Laki");
    }
    public void Kelas(){
        System.out.println("Kelas : XI");
    }
    public void Jurusan(){
        System.out.println("Jurusan : Rekayasa Perangkat Lunak");
    }
    public void Alamat(){
        System.out.println("Alamat : Jl.Masjid Perahu RT17A");
    }
    public void Ttl(){
        System.out.println("Tempat Tanggal Lahir : Pasuruan, 15 Juni 2003");
    }
    public void Hobi(){
        System.out.println("Hobi : Voli + Main Game");
    }

}
